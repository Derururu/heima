package com.jason.grade_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradeApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GradeApiApplication.class, args);
	}

}
